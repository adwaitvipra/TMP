/*	
	Write a program that Reads a CSV file with columns Name, MISID, Marks.
	Creates a doubly circular linked list of all the entries from the file.
	Then sorts this doubly linked list on MISID.
	Then Reads another CSV file with same columns,
	and inserts the entries from the second CSV file into the doubly linked
       	list in Sorted order.
	The code should be properly divided into functions and a DCLL data type.
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

typedef struct{
	char name[128];
	unsigned int mis;
	float score;
}record;

typedef struct node{
	unsigned int key;
	record *student;
	struct node *prev, *next;
}node;

typedef struct list{
	node *head;
	unsigned int size;
}list;

record *init_record(record *);
node *init_node(node *);
list *init_list(list *);

record *get_record(char *, unsigned int, float);
node *get_node(record *, unsigned int key); 

bool readcsv(list *, const char *, int *);

int main(const int argc, const char *argv[])
{
	list *base = NULL;
	base = init_list(NULL);

	return 0;
}

record *init_record(record *rptr)
{
	if(!rptr)
		rptr = (record*)malloc(sizeof(record));

	rptr->name[0] = '\0';
	rptr->mis = 0;
	rptr->score = -1.0;

	return rptr;
}

node *init_node(node *nptr)
{
	if(!nptr)
		nptr = (node*)malloc(sizeof(node));
	
	nptr->key = 0;
	nptr->student = NULL;
	nptr->prev = nptr->next = NULL;

	return nptr;
}

list *init_list(list *lptr)
{
	if(!lptr)
		lptr = (list*)malloc(sizeof(list));

	lptr->head = NULL;
	lptr->size = 0;

	return lptr;
}

record *get_record(char *str, unsigned int mis, float score)
{
	record *newrec = NULL;
	if((newrec = (record*)malloc(sizeof(record))))
	{
		strcpy(newrec->name, str);
		newrec->mis = mis;
		newrec->score = score;
	}
	return newrec;
}

node *get_node(record *student, unsigned int key) 
{
	node *newnode = NULL;
	if((newnode = (node*)malloc(sizeof(node))))
	{
		newnode->student = student;
		newnode->key = key;
		newnode->prev = newnode->next = NULL;
	}
	return newnode;
}

bool readcsv(list *lptr, const char *filename)
{
	unsigned int key;
	char strbuf[1024];
	bool flag;
	record *recptr = NULL;
	node *nodeptr = NULL;
	FILE *fh = NULL;

	flag = false;
	if((fh = fopen(filename, "r")))
	{
		fscanf(fh, "%s", strbuf); 
		while(fscanf(fh, "%s", strbuf) != EOF)
		{
			recptr = get_record(strtok(strbuf, ", "),
					(key = atoi(strtok(NULL, ","))),
					atof(strtok(NULL, ",")));
			nodeptr = get_node(recptr, key);
		}
		flag = true;
	}
	return flag;
}
