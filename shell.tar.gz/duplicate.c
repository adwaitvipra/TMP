#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>

int main(const int argc, const char *argv[])
{
	char buf[1024];
	int fd[3];
	for(int i=1; i<4;i++)
		fd[i-1] = open(argv[i], O_RDWR);

	close(0);
	close(1);
	dup(fd[0]);
	dup(fd[2]);
	while(read(0, buf, sizeof(buf)) < 1)
		write(1, buf, sizeof(buf));
	close(0);
	dup(fd[1]);
	while(read(0, buf, sizeof(buf)) < 1)
		write(1, buf, sizeof(buf));
	close(0);
	close(1);
	close(2);
	close(3);
	close(4);
	return 0;
}
