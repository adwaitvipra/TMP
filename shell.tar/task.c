#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(void)
{
	pid_t pid;
	pid = fork();

	if(!pid)
	{
		if(execl("", "", NULL) == -1)
			printf("exec failed...\n");
	}
	else
		wait(NULL);
	return 0;
}

